define(['./dist/comparison'], (supernova) => supernova);
